#include "main.h"
#include "pros/misc.h"

pros::ADIDigitalOut wingPistonLeft (LEFTWINGPORT);
pros::ADIDigitalOut wingPistonRight (RIGHTWINGPORT);

bool wingValues = false;

void moveWings(){
    wingValues = !wingValues;

    wingPistonLeft.set_value(wingValues);
    wingPistonRight.set_value(wingValues);
}

void moveRightWing(bool value){
    wingPistonRight.set_value(value);
}

void moveLeftWing(bool value){
    wingPistonLeft.set_value(value);
}


void wingsOP(){
    if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
        moveWings();
    }
    else{
        moveLeftWing(false);
        moveRightWing(false);
    }

}

    
   