#include "main.h"
#include "pros/misc.h"

pros::Motor intakeMotor (INTAKEPORT, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);


void moveIntake(int inSpeed){
    intakeMotor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    intakeMotor.move(inSpeed);
}


void intakeOP(){
    if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R1)){
        moveIntake(-127);
    }
    else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)){
        moveIntake(127);
    }
    else{
        moveIntake(0);
    }
}