#include "main.h"
#include "intake.hpp"
#include "wings.hpp"
#include "cerrno"
#include "pros/distance.hpp"
#include "pros/rtos.h"
#include "pros/rtos.hpp"
#include <cmath>

//prosv5 make && prosv5 upload

void autonOP(int mode){ 
    if (mode == 1){
        moveForward(1);
        wait(500);
        turn(10,50);
    }



   
}