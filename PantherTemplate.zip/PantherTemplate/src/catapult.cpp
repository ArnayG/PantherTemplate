#include "main.h"
#include "pros/misc.h"

bool cataOn1=false;


pros::Motor cataMotor1 (CATAPULTPORT1, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);

// pros::Motor cataMotor2 (CATA_PORT2, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);



void moveCata(int inSpeed){
    cataMotor1.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
    cataMotor1.move(inSpeed);
}


void catapultOP(){
     if (master.get_digital(pros::E_CONTROLLER_DIGITAL_A)){
        moveCata(-127);
    }
     else{
        moveCata(0);
    }
}

    
    
