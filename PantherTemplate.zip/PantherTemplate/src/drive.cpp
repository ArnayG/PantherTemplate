#include "main.h"
#include "pros/misc.h"
#include "pros/motors.h"
#include "pros/motors.hpp"
#include "pros/rtos.hpp"

//Motor Ports:
using pros::c::imu_accel_s_t;

double anRY = 0;
double anLY = 0;

bool isDriveBaseReversed = false;
bool cataOn = false;

//MOTOR CONFIG
/**
E_MOTOR_GEARSET_18 -> 200 RPM (Green motor)
E_MOTOR_GEARSET_36 -> 100 RPM (Red motor)
E_MOTOR_GEARSET_06 -> 600 RPM (Blue motor)
*/

//pros::Motor nameOfMotor (port, gearset, reversed, encoder units);
pros::Motor frontLeftDrivebase (FL_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor frontRightDrivebase (FR_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor backLeftDrivebase (BL_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor backRightDrivebase (BR_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor middleLeftDrivebase (ML_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);
pros::Motor middleRightDrivebase (MR_MOTOR, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_DEGREES);

pros::Motor rightMotors[3] = {backRightDrivebase, middleRightDrivebase, frontRightDrivebase};
pros::Motor leftMotors[3] = {backLeftDrivebase, middleLeftDrivebase, frontLeftDrivebase};




void wait(int milliseconds){
  pros::delay(milliseconds);
}

void rightForward(int inSpeed){
    for (pros::Motor motor : rightMotors){
      motor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
      motor.move(inSpeed);
    }
}

void leftForward(int inSpeed){
    for (pros::Motor motor : leftMotors){
      motor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
      motor.move(inSpeed);
    }
}



void moveForward(double seconds){
  double distance = seconds*1000 + pros::millis();;
  int rightSpeed = 90;
  int leftSpeed = 90;
  int time = pros::millis();
  if (seconds>0){
    for (int time = pros::millis(); time<=distance; time = pros::millis()){
      rightForward(rightSpeed);
      leftForward(leftSpeed);
      pros::delay(1);
    }
  }
  else{
    for (int time = pros::millis(); time<=-distance; time = pros::millis()){
      rightForward(-rightSpeed);
      leftForward(-leftSpeed);
      pros::delay(1);
    }
  }
  rightForward(0);
  leftForward(0);
}

void turn(double distance, double speed){
  distance = distance*1000;
  
  leftForward(-speed);
  rightForward(speed);

  for (int time = pros::millis(); time<=fabs(distance); time = pros::millis()){
      pros::delay(1);
  }

  rightMotors->set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  leftMotors->set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);

  leftForward(0);
  rightForward(0);
}

void driveOP(){
  rightForward(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
  leftForward(pros::E_CONTROLLER_ANALOG_LEFT_Y);
}