void moveCata(int inSpeed);
void catapultOP();