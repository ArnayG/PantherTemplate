void moveIntake(int inSpeed);
void intakeOP();