void moveWings();

void wingsOP();

void moveRightWing(bool value);
void moveLeftWing(bool value);