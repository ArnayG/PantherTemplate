void driveOP();

void wait(int milliseconds);

void moveForward(double seconds);
void rightForward(int speed);
void leftForward(int speed);

void turn(double distance, double speed);